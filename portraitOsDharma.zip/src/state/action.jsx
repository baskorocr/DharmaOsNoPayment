export const setSharedVariable = (value) => ({
    type: 'SET_SHARED_VARIABLE',
    payload: value,
  });